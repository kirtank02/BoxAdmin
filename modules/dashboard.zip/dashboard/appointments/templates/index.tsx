export default function AppointmentsTemplate() {
  return <div>AppointmentsTemplate</div>;
}
